
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.Timestamp;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author acv
 */
public class MainFrame extends javax.swing.JFrame {

    /**
     * Creates new form MainFrame
     */
    private String currentSemester;
    private String author;
    private String project;

    public MainFrame() {
        initComponents();
        checkData();
        rebuildSemesterComboBoxes();
        rebuildDropCourseStudentComboBox();
    }

    public void rebuildSemesterComboBoxes() {
        ArrayList<String> semesters = SemesterQueries.getSemesterList();
        currentSemesterComboBox.setModel(new javax.swing.DefaultComboBoxModel(semesters.toArray()));
        if (semesters.size()>0) {
            currentSemesterLabel.setText(currentSemester);
            currentSemester = currentSemesterComboBox.getSelectedItem().toString();
        } else {
            currentSemesterLabel.setText("None, add a semester.");
            currentSemester = "None";
        }
        rebuildCourseComboBoxes();
        //dont change
    }
    
    public void rebuildCourseComboBoxes() {
        ArrayList<String> courses = CourseQueries.getAllCourseCodes(currentSemester);
        SelectCourseComboBox.setModel(new javax.swing.DefaultComboBoxModel(courses.toArray()));
        DropCourseSelectCourseComboBox.setModel(new javax.swing.DefaultComboBoxModel(courses.toArray()));
        AdminDropCourseComboBox.setModel(new javax.swing.DefaultComboBoxModel(courses.toArray()));
        DisplayCourseListSelectCourseComboBox.setModel(new javax.swing.DefaultComboBoxModel(courses.toArray()));
        //dont change
        rebuildStudentComboBoxes();
    }
    
    public void rebuildStudentComboBoxes() {
        ArrayList<StudentEntry> students = StudentQueries.getAllStudents();
        ArrayList<String> studentNames = new ArrayList<>();
        
        for (StudentEntry student:students){
            String name = student.getLastname() + "," + student.getFirstname();
            studentNames.add(name);
        }
        SelectStudentComboBox.setModel(new javax.swing.DefaultComboBoxModel(studentNames.toArray()));
        DisplayStudentComboBox.setModel(new javax.swing.DefaultComboBoxModel(studentNames.toArray()));
        DropStudentSelectStudentComboBox.setModel(new javax.swing.DefaultComboBoxModel(studentNames.toArray()));
        DropCourseSelectStudentComboBox.setModel(new javax.swing.DefaultComboBoxModel(studentNames.toArray()));
        //dont change
    }
    
    public String getStudentByName(String name) {
        
            try {
            
            StudentEntry mySelectedStudent;
            String studentID = "";
            ArrayList<StudentEntry> students = new ArrayList<>();

            students = StudentQueries.getAllStudents();
            String[] studentList = name.split(",");
            String lastName = studentList[0];
            String firstName = studentList[1];

            for (StudentEntry student: students) {
                if (student.getFirstname().equals(firstName) && student.getLastname().equals(lastName)) {
                    mySelectedStudent = student;
                    studentID = mySelectedStudent.getStudentid();
                }
            }
            return studentID;
        } catch(Exception e) {
            return "";
        }
    }
    
    public void updateCourseDisplay() {
        ArrayList<CourseEntry> courses = CourseQueries.getAllCourses(currentSemester);
        
        displayCoursesTextarea.setText("Course Code\tSeats\tDescription\n");
        for (CourseEntry course: courses) {
            displayCoursesTextarea.append("\n" + course.getCourseCode() + "\t" + course.getSeats() + "\t" + course.getCourseDescription());
        }
    }
    
    public void rebuildDropCourseStudentComboBox() {
        String selectedStudent = (String)(DropCourseSelectStudentComboBox.getSelectedItem());
        String studentID = getStudentByName(selectedStudent);
        ArrayList<ScheduleEntry> schedule = ScheduleQueries.getScheduleByStudent(currentSemester, studentID);
        ArrayList<String> courseCodes = new ArrayList<>();
        for (ScheduleEntry scheduleEntry: schedule) {
            courseCodes.add(scheduleEntry.getCourseCode());
        }
        DropCourseSelectCourseComboBox.setModel(new javax.swing.DefaultComboBoxModel(courseCodes.toArray()));
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        addSemesterTextfield = new javax.swing.JTextField();
        addSemesterSubmitButton = new javax.swing.JButton();
        addSemesterStatusLabel = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        CourseCodeTextField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        CourseDescriptionTextField = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        addCourseButton = new javax.swing.JButton();
        CourseSeatsSpinner = new javax.swing.JSpinner();
        jPanel5 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        StudentIDTextField = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        FirstNameTextField = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        LastNameTextField = new javax.swing.JTextField();
        addStudentButton = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        DropStudentSelectStudentComboBox = new javax.swing.JComboBox<>();
        DropStudentButton = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        DropStudentTextArea = new javax.swing.JTextArea();
        jPanel12 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        AdminDropCourseComboBox = new javax.swing.JComboBox<>();
        AdminDropCourseButton = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        AdminDropCourseTextArea = new javax.swing.JTextArea();
        jPanel10 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        DisplayCourseListSelectCourseComboBox = new javax.swing.JComboBox<>();
        DisplayCourseListDisplayButton = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        ScheduledStudentsTextArea = new javax.swing.JTextArea();
        jLabel17 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        WaitlistedStudentsTextArea = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jPanel6 = new javax.swing.JPanel();
        DisplayCoursesButton = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        displayCoursesTextarea = new javax.swing.JTextArea();
        jPanel7 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        SelectCourseComboBox = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        SelectStudentComboBox = new javax.swing.JComboBox<>();
        ScheduleCouresButton = new javax.swing.JButton();
        ScheduleCourseStatusLabel = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        DisplayStudentComboBox = new javax.swing.JComboBox<>();
        DisplayScheduleButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        displayScheduleTextarea = new javax.swing.JTextArea();
        jPanel9 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        DropCourseSelectCourseComboBox = new javax.swing.JComboBox<>();
        DropCourseButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        DropCourseTextArea = new javax.swing.JTextArea();
        jLabel20 = new javax.swing.JLabel();
        DropCourseSelectStudentComboBox = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        currentSemesterLabel = new javax.swing.JLabel();
        currentSemesterComboBox = new javax.swing.JComboBox<>();
        changeSemesterButton = new javax.swing.JButton();
        aboutButton = new javax.swing.JButton();

        jLabel4.setText("jLabel4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Comic Sans MS", 1, 30)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 153, 153));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Course Scheduler");

        jLabel3.setText("Semester Name:");

        addSemesterTextfield.setColumns(20);
        addSemesterTextfield.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addSemesterTextfieldActionPerformed(evt);
            }
        });

        addSemesterSubmitButton.setText("Submit");
        addSemesterSubmitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addSemesterSubmitButtonActionPerformed(evt);
            }
        });

        addSemesterStatusLabel.setText("                                                   ");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(addSemesterTextfield, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addComponent(addSemesterSubmitButton))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(addSemesterStatusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 505, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(233, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(addSemesterTextfield, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(addSemesterSubmitButton)
                .addGap(18, 18, 18)
                .addComponent(addSemesterStatusLabel)
                .addContainerGap(170, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Add Semester", jPanel3);

        jLabel5.setText("Course Code:");

        jLabel6.setText("Course Description:");

        CourseDescriptionTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CourseDescriptionTextFieldActionPerformed(evt);
            }
        });

        jLabel7.setText("Course Seats:");

        addCourseButton.setText("Submit");
        addCourseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addCourseButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(CourseCodeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(CourseDescriptionTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(addCourseButton)
                            .addComponent(CourseSeatsSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(467, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(CourseCodeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(CourseDescriptionTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(CourseSeatsSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(addCourseButton)
                .addContainerGap(127, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Add Course", jPanel4);

        jLabel8.setText("StudentID:");

        jLabel9.setText("FirstName:");

        FirstNameTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FirstNameTextFieldActionPerformed(evt);
            }
        });

        jLabel10.setText("LastName:");

        addStudentButton.setText("Submit");
        addStudentButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addStudentButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(StudentIDTextField))
                    .addComponent(addStudentButton)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(18, 18, 18)
                        .addComponent(LastNameTextField))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(FirstNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(513, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(StudentIDTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(FirstNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(LastNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addComponent(addStudentButton)
                .addContainerGap(130, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Add Student", jPanel5);

        jLabel18.setText("Select Student:");

        DropStudentSelectStudentComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        DropStudentSelectStudentComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DropStudentSelectStudentComboBoxActionPerformed(evt);
            }
        });

        DropStudentButton.setText("Drop Student");
        DropStudentButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DropStudentButtonActionPerformed(evt);
            }
        });

        DropStudentTextArea.setColumns(20);
        DropStudentTextArea.setRows(5);
        jScrollPane6.setViewportView(DropStudentTextArea);

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 474, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addGap(18, 18, 18)
                        .addComponent(DropStudentSelectStudentComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(DropStudentButton)))
                .addContainerGap(264, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(DropStudentSelectStudentComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(DropStudentButton))
                    .addComponent(jLabel18))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(61, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Drop Student", jPanel11);

        jLabel19.setText("Select Course to be Dropped");

        AdminDropCourseComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        AdminDropCourseComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdminDropCourseComboBoxActionPerformed(evt);
            }
        });

        AdminDropCourseButton.setText("Drop Course");
        AdminDropCourseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdminDropCourseButtonActionPerformed(evt);
            }
        });

        AdminDropCourseTextArea.setColumns(20);
        AdminDropCourseTextArea.setRows(5);
        jScrollPane7.setViewportView(AdminDropCourseTextArea);

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 512, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addGap(18, 18, 18)
                        .addComponent(AdminDropCourseComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(AdminDropCourseButton)))
                .addContainerGap(226, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(AdminDropCourseComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(AdminDropCourseButton))
                    .addComponent(jLabel19))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(64, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Drop Course", jPanel12);

        jLabel15.setText("Select Course:");

        DisplayCourseListSelectCourseComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        DisplayCourseListSelectCourseComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DisplayCourseListSelectCourseComboBoxActionPerformed(evt);
            }
        });

        DisplayCourseListDisplayButton.setText("Display");
        DisplayCourseListDisplayButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DisplayCourseListDisplayButtonActionPerformed(evt);
            }
        });

        jLabel16.setText("Scheduled Students");

        ScheduledStudentsTextArea.setColumns(20);
        ScheduledStudentsTextArea.setRows(5);
        jScrollPane4.setViewportView(ScheduledStudentsTextArea);

        jLabel17.setText("Waitlisted Students");

        WaitlistedStudentsTextArea.setColumns(20);
        WaitlistedStudentsTextArea.setRows(5);
        jScrollPane5.setViewportView(WaitlistedStudentsTextArea);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(DisplayCourseListSelectCourseComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51)
                        .addComponent(DisplayCourseListDisplayButton))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel16)
                            .addComponent(jLabel17)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 406, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(316, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(DisplayCourseListSelectCourseComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DisplayCourseListDisplayButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Display Course List of Students ", jPanel10);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane2)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Admin", jPanel1);

        DisplayCoursesButton.setText("Display");
        DisplayCoursesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DisplayCoursesButtonActionPerformed(evt);
            }
        });

        displayCoursesTextarea.setColumns(20);
        displayCoursesTextarea.setRows(5);
        jScrollPane3.setViewportView(displayCoursesTextarea);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(488, 488, 488)
                        .addComponent(DisplayCoursesButton))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(DisplayCoursesButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane3.addTab("Display Courses", jPanel6);

        jLabel11.setText("Select Course:");

        SelectCourseComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        SelectCourseComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectCourseComboBoxActionPerformed(evt);
            }
        });

        jLabel12.setText("Select Student:");

        SelectStudentComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        SelectStudentComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectStudentComboBoxActionPerformed(evt);
            }
        });

        ScheduleCouresButton.setText("Submit");
        ScheduleCouresButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ScheduleCouresButtonActionPerformed(evt);
            }
        });

        ScheduleCourseStatusLabel.setText(" ");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(ScheduleCouresButton)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addGap(53, 53, 53)
                                .addComponent(SelectCourseComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(SelectStudentComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(ScheduleCourseStatusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 487, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(SelectCourseComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(SelectStudentComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(ScheduleCouresButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ScheduleCourseStatusLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane3.addTab("Schedule Course", jPanel7);

        jLabel13.setText("Select Student:");

        DisplayStudentComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        DisplayStudentComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DisplayStudentComboBoxActionPerformed(evt);
            }
        });

        DisplayScheduleButton.setText("Display");
        DisplayScheduleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DisplayScheduleButtonActionPerformed(evt);
            }
        });

        displayScheduleTextarea.setColumns(20);
        displayScheduleTextarea.setRows(5);
        jScrollPane2.setViewportView(displayScheduleTextarea);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addGap(33, 33, 33)
                        .addComponent(DisplayStudentComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(DisplayScheduleButton)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 447, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(303, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(DisplayStudentComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(DisplayScheduleButton)
                .addContainerGap(49, Short.MAX_VALUE))
        );

        jTabbedPane3.addTab("Display Schedule", jPanel8);

        jLabel14.setText("Select Course:");

        DropCourseSelectCourseComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        DropCourseSelectCourseComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DropCourseSelectCourseComboBoxActionPerformed(evt);
            }
        });

        DropCourseButton.setText("Drop Course");
        DropCourseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DropCourseButtonActionPerformed(evt);
            }
        });

        DropCourseTextArea.setColumns(20);
        DropCourseTextArea.setRows(5);
        jScrollPane1.setViewportView(DropCourseTextArea);

        jLabel20.setText("Select Sudent:");

        DropCourseSelectStudentComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        DropCourseSelectStudentComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DropCourseSelectStudentComboBoxActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel14)
                        .addGap(18, 18, 18)
                        .addComponent(DropCourseSelectCourseComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31)
                        .addComponent(jLabel20)
                        .addGap(18, 18, 18)
                        .addComponent(DropCourseSelectStudentComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(DropCourseButton))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 491, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(236, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(DropCourseSelectCourseComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20)
                    .addComponent(DropCourseSelectStudentComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(DropCourseButton)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(62, Short.MAX_VALUE))
        );

        jTabbedPane3.addTab("Drop Course", jPanel9);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane3)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane3, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        jTabbedPane1.addTab("Student", jPanel2);

        jLabel2.setFont(new java.awt.Font("Comic Sans MS", 1, 16)); // NOI18N
        jLabel2.setText("Current Semester: ");

        currentSemesterLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 16)); // NOI18N
        currentSemesterLabel.setText("           ");

        currentSemesterComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        currentSemesterComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                currentSemesterComboBoxActionPerformed(evt);
            }
        });

        changeSemesterButton.setText("Change Semester");
        changeSemesterButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changeSemesterButtonActionPerformed(evt);
            }
        });

        aboutButton.setText("About");
        aboutButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabbedPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(currentSemesterLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(currentSemesterComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(changeSemesterButton)
                                .addGap(31, 31, 31)
                                .addComponent(aboutButton)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(currentSemesterLabel)
                    .addComponent(currentSemesterComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(changeSemesterButton)
                    .addComponent(aboutButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addSemesterSubmitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addSemesterSubmitButtonActionPerformed
        String semester = addSemesterTextfield.getText();
        SemesterQueries.addSemester(semester);
        addSemesterStatusLabel.setText("Semester " + semester + " has been added.");
        rebuildSemesterComboBoxes();
        //dont change
    }//GEN-LAST:event_addSemesterSubmitButtonActionPerformed

    private void aboutButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutButtonActionPerformed
        JOptionPane.showMessageDialog(null, "Author: " + author + " Project: " + project);
        //dont change
    }//GEN-LAST:event_aboutButtonActionPerformed

    private void DisplayCoursesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DisplayCoursesButtonActionPerformed
        ArrayList<CourseEntry> courses = CourseQueries.getAllCourses(currentSemesterLabel.getText());
        
        displayCoursesTextarea.setText("Course Code\tSeats\tDescription\n");
        for (CourseEntry course:courses){
            displayCoursesTextarea.append(course.getCourseCode()+ "\t" + course.getSeats() + "\t" + course.getCourseDescription() + "\n");
        }
        //dont change
    }//GEN-LAST:event_DisplayCoursesButtonActionPerformed

    private void DisplayScheduleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DisplayScheduleButtonActionPerformed
        ArrayList<StudentEntry> students = StudentQueries.getAllStudents();
        String studentID = students.get(DisplayStudentComboBox.getSelectedIndex()).getStudentid();
        ArrayList<ScheduleEntry> schedule = ScheduleQueries.getScheduleByStudent(currentSemesterLabel.getText(), studentID);
                
        displayScheduleTextarea.setText("Course Code\tStatus\n");
        for (ScheduleEntry entry:schedule) {
            String line = entry.getCourseCode()+ "\t";
            switch (entry.getStatus()){
                case "s":
                    line += "scheduled\n";
                break;
                case "w":
                    line += "waitlisted\n";
                break;
            }
            displayScheduleTextarea.append(line);
        }
        rebuildStudentComboBoxes();
      //dont change
    }//GEN-LAST:event_DisplayScheduleButtonActionPerformed

    private void CourseDescriptionTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CourseDescriptionTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CourseDescriptionTextFieldActionPerformed

    private void addSemesterTextfieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addSemesterTextfieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addSemesterTextfieldActionPerformed

    private void addCourseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addCourseButtonActionPerformed
        // TODO add your handling code here:
        String courseCode = CourseCodeTextField.getText();
        String courseDescription = CourseDescriptionTextField.getText();
        int courseSeats = (int) CourseSeatsSpinner.getValue();
        CourseEntry course = new CourseEntry (currentSemesterLabel.getText(), courseCode, courseDescription, courseSeats);
        CourseQueries.addCourse(course);
        addSemesterStatusLabel.setText("Course " + courseCode + " has been added.");
        rebuildCourseComboBoxes();
        //dont change
    }//GEN-LAST:event_addCourseButtonActionPerformed

    private void addStudentButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addStudentButtonActionPerformed
        // TODO add your handling code here:
        String studentid = StudentIDTextField.getText();
        String firstname = FirstNameTextField.getText();
        String lastname = LastNameTextField.getText();
        StudentEntry student = new StudentEntry (studentid, firstname, lastname);
        StudentQueries.addStudent(student);
        addSemesterStatusLabel.setText("Student " + studentid + " has been added.");
        rebuildStudentComboBoxes();
        //dont change
    }//GEN-LAST:event_addStudentButtonActionPerformed

    private void FirstNameTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FirstNameTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FirstNameTextFieldActionPerformed

    private void changeSemesterButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changeSemesterButtonActionPerformed
         // TODO add your handling code here:
        String semester = currentSemesterComboBox.getSelectedItem().toString();
        currentSemesterLabel.setText(semester);
        currentSemester = semester;
        rebuildSemesterComboBoxes();
        //dont change
    }//GEN-LAST:event_changeSemesterButtonActionPerformed

    private void SelectCourseComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelectCourseComboBoxActionPerformed
        String currentSemester = currentSemesterLabel.getText();

        ArrayList<CourseEntry> courses = CourseQueries.getAllCourses(currentSemester);
        
        for (CourseEntry course : courses) {
            SelectCourseComboBox.addItem(course.getCourseCode());
        }
        
    }//GEN-LAST:event_SelectCourseComboBoxActionPerformed

    private void ScheduleCouresButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ScheduleCouresButtonActionPerformed
        // TODO add your handling code here:
        
        String courseCode = SelectCourseComboBox.getSelectedItem().toString();
         
        ArrayList<StudentEntry> students = StudentQueries.getAllStudents();
        String studentID = students.get(SelectStudentComboBox.getSelectedIndex()).getStudentid();
        
        java.sql.Timestamp timestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
        
        int seatsPossible = CourseQueries.getCourseSeats(currentSemesterLabel.getText(), courseCode);
        int reservedSeats = ScheduleQueries.getScheduledStudentCount(currentSemesterLabel.getText(),courseCode);
        
        if (reservedSeats < seatsPossible){
            ScheduleEntry student = new ScheduleEntry(currentSemesterLabel.getText(), courseCode, studentID, "s", timestamp);
            ScheduleQueries.addScheduleEntry(student);
            ScheduleCourseStatusLabel.setText(SelectStudentComboBox.getSelectedItem().toString()+ "has been scheduled for class");
        }
        else {
            ScheduleEntry student = new ScheduleEntry(currentSemesterLabel.getText(), courseCode, studentID, "w", timestamp);
            ScheduleQueries.addScheduleEntry(student);
            ScheduleCourseStatusLabel.setText(SelectStudentComboBox.getSelectedItem().toString()+ "has been waitlisted for class");
        }
        rebuildCourseComboBoxes();
        rebuildStudentComboBoxes();
        //dont change
    }//GEN-LAST:event_ScheduleCouresButtonActionPerformed

    private void currentSemesterComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_currentSemesterComboBoxActionPerformed
    ArrayList<String> semesters = SemesterQueries.getSemesterList();
    
    for (String semester : semesters) {
        currentSemesterComboBox.addItem(semester);
    }
   
    }//GEN-LAST:event_currentSemesterComboBoxActionPerformed

    private void SelectStudentComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelectStudentComboBoxActionPerformed

        ArrayList<StudentEntry> students = StudentQueries.getAllStudents();

        
        for (StudentEntry student : students) {
            
            SelectStudentComboBox.addItem(student.getFirstname() + " " + student.getLastname());
        }
       
    }//GEN-LAST:event_SelectStudentComboBoxActionPerformed

    private void DisplayStudentComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DisplayStudentComboBoxActionPerformed
        String selectedCourse = (String) SelectCourseComboBox.getSelectedItem();

        ArrayList<StudentEntry> students = StudentQueries.getAllStudents();
        
        for (StudentEntry student : students) {
            
            DisplayStudentComboBox.addItem(student.getFirstname() + " " + student.getLastname());
        }
    }//GEN-LAST:event_DisplayStudentComboBoxActionPerformed

    private void DropStudentSelectStudentComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DropStudentSelectStudentComboBoxActionPerformed
        ArrayList<StudentEntry> students = StudentQueries.getAllStudents();

        for (StudentEntry student : students) {
            
            DropStudentSelectStudentComboBox.addItem(student.getFirstname() + " " + student.getLastname());
        }
       rebuildDropCourseStudentComboBox();
    }//GEN-LAST:event_DropStudentSelectStudentComboBoxActionPerformed

    private void DropStudentButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DropStudentButtonActionPerformed
         DropStudentTextArea.setText("");
        
        String selectedStudent = (String)(DropStudentSelectStudentComboBox.getSelectedItem());
        
        if (selectedStudent == null) {
            return;
        }
        
        String studentID = getStudentByName(selectedStudent);
        
        StudentQueries.dropStudent(studentID);
        DropStudentTextArea.setText(selectedStudent + " has been dropped. ");
        rebuildDropCourseStudentComboBox();
        
       
        ArrayList<String> allSemesters = SemesterQueries.getSemesterList();
        
        for (String semester: allSemesters) {            

            ArrayList<ScheduleEntry> studentSchedule = ScheduleQueries.getScheduleByStudent(semester, studentID);
            
            for (int i = 0; i < studentSchedule.size(); i++) {
                if (studentSchedule.get(i).getStatus().equals("w")) {
                    DropStudentTextArea.append("\n" + selectedStudent + ", " + studentSchedule.get(i).getStudentID() + ", has been removed from the waitlist of " + studentSchedule.get(i).getCourseCode() + " for semester " + semester);
                    studentSchedule.remove(i);
                }
            }
            
            ScheduleQueries.deleteScheduleByStudent(semester, studentID);
            ArrayList<String> courseCodes = new ArrayList<>();
            for (ScheduleEntry scheduleEntry: studentSchedule) {
                courseCodes.add(scheduleEntry.getCourseCode());
                DropStudentTextArea.append("\n" + selectedStudent + ", " + scheduleEntry.getStudentID() + ", has been removed from " + scheduleEntry.getCourseCode() + " for semester " + semester);
                       
                CourseQueries.addSeat(currentSemester, scheduleEntry.getCourseCode());
            }
            updateCourseDisplay();
            
            for (String courseCode: courseCodes) {
                
                ArrayList<ScheduleEntry> schedules = ScheduleQueries.getScheduledStudentsByCourse(semester, courseCode);
                
                for (ScheduleEntry scheduleEntry: schedules) {
                    if (scheduleEntry.getStatus().equals("w")) {
                        ScheduleQueries.updateScheduleEntry(semester, scheduleEntry);
                        StudentEntry name = StudentQueries.getStudent(scheduleEntry.getStudentID());
                        String firstName = name.getFirstname();
                        String lastName = name.getLastname();
                        DropStudentTextArea.append("\n" + firstName + " " + lastName  + ", " + scheduleEntry.getStudentID() + ", has been enrolled in " + courseCode + " for semester " + semester);
                        CourseQueries.RemoveSeat(currentSemester, scheduleEntry.getCourseCode());
                        updateCourseDisplay();
                        break;
                    }
                }
            }
            DropStudentTextArea.append("\n");
        }
        
        DropStudentTextArea.append("\n" + selectedStudent + " has been removed from all the student combo boxes.");
    
        rebuildStudentComboBoxes();
    }//GEN-LAST:event_DropStudentButtonActionPerformed

    private void DropCourseSelectCourseComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DropCourseSelectCourseComboBoxActionPerformed
        String currentSemester = currentSemesterLabel.getText();

        ArrayList<CourseEntry> courses = CourseQueries.getAllCourses(currentSemester);
        
        for (CourseEntry course : courses) {
            DropCourseSelectCourseComboBox.addItem(course.getCourseCode());
        }
        rebuildDropCourseStudentComboBox();
    }//GEN-LAST:event_DropCourseSelectCourseComboBoxActionPerformed

    private void DropCourseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DropCourseButtonActionPerformed
        DropCourseTextArea.setText("");
        
        String selectedCourse = (String)(DropCourseSelectCourseComboBox.getSelectedItem());
        
        String selectedStudent = (String)(DropCourseSelectStudentComboBox.getSelectedItem());
        String studentID = getStudentByName(selectedStudent);
        
        
        ArrayList<ScheduleEntry> studentSchedule = ScheduleQueries.getScheduleByStudent(currentSemester, studentID);
        for (ScheduleEntry schedule: studentSchedule) {
            if (schedule.getCourseCode().equals(selectedCourse)) {
                if (schedule.getStatus().equals("s")) {
                    DropCourseTextArea.append(selectedCourse + " has been dropped for " + selectedStudent + ", " + schedule.getStudentID() + ".");
                    CourseQueries.addSeat(currentSemester, schedule.getCourseCode());
                    ArrayList<CourseEntry> courses = CourseQueries.getAllCourses(currentSemester);
        
                    DropCourseTextArea.setText("Course Code\tSeats\tDescription\n");
                    for (CourseEntry course: courses) {
                        DropCourseTextArea.append("\n" + course.getCourseCode() + "\t" + course.getSeats() + "\t" + course.getCourseDescription());
                    }
                } else {
                    DropCourseTextArea.append("You have been unwaitlisted from " + selectedCourse + ".");
                }
            }
        }
        
        ScheduleQueries.dropStudentScheduleByCourse(currentSemester, studentID, selectedCourse);
        rebuildDropCourseStudentComboBox();
 
        ArrayList<ScheduleEntry> schedules = ScheduleQueries.getScheduledStudentsByCourse(currentSemester, selectedCourse);
        
        for (ScheduleEntry scheduleEntry: schedules) {
            if (scheduleEntry.getStatus().equals("w")) {
                ScheduleQueries.updateScheduleEntry(currentSemester, scheduleEntry);
                StudentEntry name = StudentQueries.getStudent(scheduleEntry.getStudentID());
                String firstName = name.getFirstname();
                String lastName = name.getLastname();
                        
                DropCourseTextArea.append("\n" + firstName + " " + lastName + " has been enrolled in " + selectedCourse);
                CourseQueries.RemoveSeat(currentSemester, scheduleEntry.getCourseCode());
                ArrayList<CourseEntry> courses = CourseQueries.getAllCourses(currentSemester);
        
                    DropCourseTextArea.setText("Course Code\tSeats\tDescription\n");
                    for (CourseEntry course: courses) {
                        DropCourseTextArea.append("\n" + course.getCourseCode() + "\t" + course.getSeats() + "\t" + course.getCourseDescription());
                    }
                break;
            }
        }
        rebuildDropCourseStudentComboBox();
        
                
    }//GEN-LAST:event_DropCourseButtonActionPerformed

    private void AdminDropCourseComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdminDropCourseComboBoxActionPerformed
       String currentSemester = currentSemesterLabel.getText();

        ArrayList<CourseEntry> courses = CourseQueries.getAllCourses(currentSemester);
        
        for (CourseEntry course : courses) {
            AdminDropCourseComboBox.addItem(course.getCourseCode());
        }
        rebuildDropCourseStudentComboBox();
    }//GEN-LAST:event_AdminDropCourseComboBoxActionPerformed

    private void AdminDropCourseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdminDropCourseButtonActionPerformed

        AdminDropCourseTextArea.setText("");
        
        String selectedCourse = (String)(AdminDropCourseComboBox.getSelectedItem());
        
        if (selectedCourse == null) {
            return;
        }
        
        AdminDropCourseTextArea.append(selectedCourse + " has been removed.");
        
            ArrayList<ScheduleEntry> allSchedules = ScheduleQueries.getAllSchedules(currentSemester);
            
        for (ScheduleEntry scheduleEntry: allSchedules) {
            if (scheduleEntry.getCourseCode().equals(selectedCourse)) {
                    ScheduleQueries.dropScheduleByCourse(currentSemester, selectedCourse);
                    
                    StudentEntry name = StudentQueries.getStudent(scheduleEntry.getStudentID());
                    String firstName = name.getFirstname();
                    String lastName = name.getLastname();
                    
                    if (scheduleEntry.getStatus().equals("s")) {
                        AdminDropCourseTextArea.append("\n" + firstName + " " + lastName + " has been removed from " + selectedCourse + ".");
                    } else {
                        AdminDropCourseTextArea.append("\n" + firstName + " " + lastName + " has been removed from the waitlist of " + selectedCourse + ".");
                    }
            }
        }
            
        CourseQueries.deleteCourse(currentSemester, selectedCourse);
        
        updateCourseDisplay(); 
        rebuildCourseComboBoxes();
    
    }//GEN-LAST:event_AdminDropCourseButtonActionPerformed

    private void DisplayCourseListSelectCourseComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DisplayCourseListSelectCourseComboBoxActionPerformed
       String currentSemester = currentSemesterLabel.getText();

        ArrayList<CourseEntry> courses = CourseQueries.getAllCourses(currentSemester);
        
        for (CourseEntry course : courses) {
            DisplayCourseListSelectCourseComboBox.addItem(course.getCourseCode());
        }
    }//GEN-LAST:event_DisplayCourseListSelectCourseComboBoxActionPerformed

    private void DisplayCourseListDisplayButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DisplayCourseListDisplayButtonActionPerformed
        ScheduledStudentsTextArea.setText("");
        WaitlistedStudentsTextArea.setText("");

        String courseCode = (String)(DisplayCourseListSelectCourseComboBox.getSelectedItem());
        ArrayList<ScheduleEntry> schedules = ScheduleQueries.getScheduledStudentsByCourse(currentSemester, courseCode);
        ArrayList<ScheduleEntry> waitList = new ArrayList<>();

        ScheduledStudentsTextArea.append("Name\tStudent ID\tStatus\n");
        WaitlistedStudentsTextArea.append("Name\tStudent ID\tStatus\n");
        
        for (ScheduleEntry scheduleEntry: schedules) {
            if ((scheduleEntry.getStatus()).equals("s")) {
                StudentEntry name = StudentQueries.getStudent(scheduleEntry.getStudentID());
                ScheduledStudentsTextArea.append(name.getFirstname() + " " + name.getLastname() + "\t" + scheduleEntry.getStudentID() + "\t" + scheduleEntry.getStatus() + "\n");
            } else {
                waitList.add(scheduleEntry);
            }
        }

        for (ScheduleEntry scheduleEntry: waitList) {
            StudentEntry name = StudentQueries.getStudent(scheduleEntry.getStudentID());
            WaitlistedStudentsTextArea.append(name.getFirstname() + " " + name.getLastname() + "\t" + scheduleEntry.getStudentID() + "\t" + scheduleEntry.getStatus() + "\n");
        }
    }//GEN-LAST:event_DisplayCourseListDisplayButtonActionPerformed

    private void DropCourseSelectStudentComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DropCourseSelectStudentComboBoxActionPerformed
         ArrayList<StudentEntry> students = StudentQueries.getAllStudents();
        
        for (StudentEntry student : students) {
            
            DropCourseSelectStudentComboBox.addItem(student.getFirstname() + " " + student.getLastname());
        }
        rebuildDropCourseStudentComboBox();
    }//GEN-LAST:event_DropCourseSelectStudentComboBoxActionPerformed

    private void checkData() {
        try {
            FileReader reader = new FileReader("xzq789yy.txt");
            BufferedReader breader = new BufferedReader(reader);

            String encodedAuthor = breader.readLine();
            String encodedProject = breader.readLine();
            byte[] decodedAuthor = Base64.getDecoder().decode(encodedAuthor);
            author = new String(decodedAuthor);
            byte[] decodedProject = Base64.getDecoder().decode(encodedProject);
            project = new String(decodedProject);
            reader.close();

        } catch (FileNotFoundException e) {
            //get user info and create file
            author = JOptionPane.showInputDialog("Enter your first and last name.");
            project = "Course Scheduler Spring 2023";

            //write data to the data file.
            try {
                FileWriter writer = new FileWriter("xzq789yy.txt", true);
                BufferedWriter bufferedWriter = new BufferedWriter(writer);

                // encode the output data.
                String encodedAuthor = Base64.getEncoder().encodeToString(author.getBytes());

                bufferedWriter.write(encodedAuthor);
                bufferedWriter.newLine();

                String encodedProject = Base64.getEncoder().encodeToString(project.getBytes());
                bufferedWriter.write(encodedProject);

                bufferedWriter.close();
            } catch (IOException ioe) {
                ioe.printStackTrace();
                System.exit(1);
            }

        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AdminDropCourseButton;
    private javax.swing.JComboBox<String> AdminDropCourseComboBox;
    private javax.swing.JTextArea AdminDropCourseTextArea;
    private javax.swing.JTextField CourseCodeTextField;
    private javax.swing.JTextField CourseDescriptionTextField;
    private javax.swing.JSpinner CourseSeatsSpinner;
    private javax.swing.JButton DisplayCourseListDisplayButton;
    private javax.swing.JComboBox<String> DisplayCourseListSelectCourseComboBox;
    private javax.swing.JButton DisplayCoursesButton;
    private javax.swing.JButton DisplayScheduleButton;
    private javax.swing.JComboBox<String> DisplayStudentComboBox;
    private javax.swing.JButton DropCourseButton;
    private javax.swing.JComboBox<String> DropCourseSelectCourseComboBox;
    private javax.swing.JComboBox<String> DropCourseSelectStudentComboBox;
    private javax.swing.JTextArea DropCourseTextArea;
    private javax.swing.JButton DropStudentButton;
    private javax.swing.JComboBox<String> DropStudentSelectStudentComboBox;
    private javax.swing.JTextArea DropStudentTextArea;
    private javax.swing.JTextField FirstNameTextField;
    private javax.swing.JTextField LastNameTextField;
    private javax.swing.JButton ScheduleCouresButton;
    private javax.swing.JLabel ScheduleCourseStatusLabel;
    private javax.swing.JTextArea ScheduledStudentsTextArea;
    private javax.swing.JComboBox<String> SelectCourseComboBox;
    private javax.swing.JComboBox<String> SelectStudentComboBox;
    private javax.swing.JTextField StudentIDTextField;
    private javax.swing.JTextArea WaitlistedStudentsTextArea;
    private javax.swing.JButton aboutButton;
    private javax.swing.JButton addCourseButton;
    private javax.swing.JLabel addSemesterStatusLabel;
    private javax.swing.JButton addSemesterSubmitButton;
    private javax.swing.JTextField addSemesterTextfield;
    private javax.swing.JButton addStudentButton;
    private javax.swing.JButton changeSemesterButton;
    private javax.swing.JComboBox<String> currentSemesterComboBox;
    private javax.swing.JLabel currentSemesterLabel;
    private javax.swing.JTextArea displayCoursesTextarea;
    private javax.swing.JTextArea displayScheduleTextarea;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane3;
    // End of variables declaration//GEN-END:variables
}

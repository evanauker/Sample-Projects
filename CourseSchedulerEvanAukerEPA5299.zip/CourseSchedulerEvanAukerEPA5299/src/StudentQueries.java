/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author evana
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class StudentQueries {
    private static Connection connection;
    private static ArrayList<StudentEntry> faculty = new ArrayList<StudentEntry>();
    private static PreparedStatement queryaddStudent;
    private static PreparedStatement querygetAllStudents;
    private static PreparedStatement querygetStudent;
    private static ResultSet resultSet;
    
    public static void addStudent(StudentEntry student){
        
        connection = DBConnection.getConnection();
        try
            {
                queryaddStudent = connection.prepareStatement("insert into app.student (studentid,firstname,lastname) values (?,?,?)");
                queryaddStudent.setString(1, student.getStudentid());
                queryaddStudent.setString(2, student.getFirstname());
                queryaddStudent.setString(3, student.getLastname());
                queryaddStudent.executeUpdate();
            }    
            catch(SQLException sqlException)
            {
                sqlException.printStackTrace();
            }  
    }
    
    public static ArrayList<StudentEntry> getAllStudents(){
       
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<StudentEntry>();
        try
        {
            querygetAllStudents = connection.prepareStatement("select studentid, firstname, lastname from app.student order by firstname");
            resultSet = querygetAllStudents.executeQuery();
            
            while(resultSet.next())
            {
                StudentEntry student = new StudentEntry(resultSet.getString(1),resultSet.getString(2),resultSet.getString(3));
                students.add(student);
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return students;
       
    }
    public static StudentEntry getStudent(String studentID) {
        connection = DBConnection.getConnection();
        StudentEntry student = null;

        try {
            querygetStudent = connection.prepareStatement("select firstname, lastname from app.student where studentID = ?");
            querygetStudent.setString(1, studentID);
            resultSet = querygetStudent.executeQuery();

            if (resultSet.next()) {
                student = new StudentEntry(studentID, resultSet.getString("firstname"), resultSet.getString("lastname"));
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return student;

    }
    
    public static void dropStudent(String studentID) {
        connection = DBConnection.getConnection();
        
        try
        {
            querygetAllStudents = connection.prepareStatement("delete from app.student where studentid=?");
            querygetAllStudents.setString(1, studentID);
            
            querygetAllStudents.executeUpdate();
            
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author evana
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Timestamp;

public class ScheduleQueries {
    private static Connection connection;
    private static ArrayList<String> faculty = new ArrayList<>();
    private static PreparedStatement Schedule;
    private static ResultSet resultSet;
    
    
    public static void addScheduleEntry(ScheduleEntry entry){
        
        connection = DBConnection.getConnection();
        try
            {
                Schedule = connection.prepareStatement("insert into app.schedule (semester,studentID,courseCode,status) values (?,?,?,?)");
                Schedule.setString(1, entry.getSemester());
                Schedule.setString(2, entry.getCourseCode());
                Schedule.setString(3, entry.getStudentID());
                Schedule.setString(4, entry.getStatus());
                Schedule.executeUpdate();
            }    
            catch(SQLException sqlException)
            {
                sqlException.printStackTrace();
            }  
    }
    
    public static ArrayList<ScheduleEntry> getScheduleByStudent(String semester, String studentID){
        
        ArrayList<ScheduleEntry> getScheduleByStudent = new ArrayList<>();
        connection = DBConnection.getConnection();
        try
        {
            Schedule = connection.prepareStatement("select semester, courseCode, studentID, status, timestamp from app.schedule where semester = ? and studentID = ?");
            Schedule.setString(1, semester);
            Schedule.setString(2, studentID);
            resultSet = Schedule.executeQuery();
            
            while(resultSet.next())
            {
                ScheduleEntry schedule = new ScheduleEntry(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getTimestamp(5));
                getScheduleByStudent.add(schedule);
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return getScheduleByStudent;  
    }
    
    public static int getScheduledStudentCount (String currentSemester, String courseCode){
        
        int scheduledStudents = 0;
        connection = DBConnection.getConnection();
        
        try
        {
            Schedule = connection.prepareStatement("select count(studentID) from app.schedule where semester = ? and courseCode = ?");
            Schedule.setString(1, currentSemester);
            Schedule.setString(2, courseCode);
            resultSet = Schedule.executeQuery();
            
            while(resultSet.next())
            {
                scheduledStudents = resultSet.getInt(1);
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return scheduledStudents;
    }
    
    public static ArrayList<ScheduleEntry> getAllSchedules(String currentSemester) {
        connection = DBConnection.getConnection();
        
        ArrayList<ScheduleEntry> schedules = new ArrayList<>();
        try {
            Schedule = connection.prepareStatement("select semester, coursecode, studentid, status, timestamp from app.schedule where semester = ?");
            Schedule.setString(1, currentSemester);
            
            resultSet = Schedule.executeQuery();
            
            while (resultSet.next()) {
                schedules.add(new ScheduleEntry(resultSet.getString(1), resultSet.getString(3), resultSet.getString(2), resultSet.getString(4), resultSet.getTimestamp(5)));
            }

        } catch(SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return schedules;
    }
    
    public static ArrayList<ScheduleEntry> getScheduledStudentsByCourse(String semester, String courseCode) {
        
        ArrayList<ScheduleEntry> scheduled = new ArrayList<>();
        ArrayList<ScheduleEntry> schedules = ScheduleQueries.getAllSchedules(semester);
            
        for (ScheduleEntry schedule: schedules) {
            if (schedule.getCourseCode().equals(courseCode)) {
                scheduled.add(schedule);
            }
        }
    
        return scheduled;
    }
    
    public static ArrayList<ScheduleEntry> getWaitlistedStudentsByCourse(String semester, String courseCode) {
        
        ArrayList<ScheduleEntry> waitlisted = new ArrayList<>();
        ArrayList<ScheduleEntry> schedules = ScheduleQueries.getAllSchedules(semester);
            
        for (ScheduleEntry schedule: schedules) {
            if (schedule.getCourseCode().equals(courseCode)) {
                if (schedule.getStatus().equals("w")) {
                    waitlisted.add(schedule);
                }
            }
        }
        
        return waitlisted;
    }
    
     public static void dropStudentScheduleByCourse(String semester, String studentID, String courseCode) {
        connection = DBConnection.getConnection();
        
        ArrayList<ScheduleEntry> schedules = new ArrayList<>();
        try {
            Schedule = connection.prepareStatement("delete from app.schedule where semester = ? and studentid = ? and coursecode = ?");
            Schedule.setString(1, semester);
            Schedule.setString(2, studentID);
            Schedule.setString(3, courseCode);
            
            Schedule.executeUpdate();
            
        } catch(SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }
   
    public static void dropScheduleByCourse(String semester, String courseCode) {
        connection = DBConnection.getConnection();
        
        try {
            Schedule = connection.prepareStatement("delete from app.schedule where semester = ? and coursecode = ?");
            Schedule.setString(1, semester);
            Schedule.setString(2, courseCode);
            
            Schedule.executeUpdate();
            
        } catch(SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }
    
    public static void updateScheduleEntry(String semester, ScheduleEntry entry) {
        connection = DBConnection.getConnection();
        
        try {
            
            Schedule = connection.prepareStatement("update app.schedule set status=? where semester=? and studentid=? and coursecode=?");
            Schedule.setString(1, "Enrolled"); 
            Schedule.setString(2, semester);
            Schedule.setString(3, entry.getStudentID());
            Schedule.setString(3, entry.getCourseCode());
            
            Schedule.executeUpdate();
    
        } catch(SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }
    
     public static void deleteScheduleByStudent(String semester, String studentID) {
        connection = DBConnection.getConnection();
        
        ArrayList<ScheduleEntry> schedules = new ArrayList<>();
        try {
            Schedule = connection.prepareStatement("delete from app.schedule where semester = ? and studentid = ?");
            Schedule.setString(1, semester);
            Schedule.setString(2, studentID);
            
            Schedule.executeUpdate();
            
            
            

        } catch(SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }
}

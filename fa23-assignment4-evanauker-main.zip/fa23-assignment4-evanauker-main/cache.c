#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>

#include "cache.h"
#include "jbod.h"

static cache_entry_t *cache = NULL;
static int cache_size = 0;
static int clock = 0;
static int num_queries = 0;
static int num_hits = 0;

int find_least_recently_used(void);

int cache_create(int num_entries) {
    
    if (cache != NULL || num_entries < 2 || num_entries > 4096) {
        return -1; // Cache already created or invalid number of entries
    }

    // Allocate space for num_entries cache entries
    cache = malloc(num_entries * sizeof(cache_entry_t));
    if (cache == NULL) {
        return -1; // Memory allocation failed
    }

    // Initialize other variables
    cache_size = num_entries;
    clock = 0;
    num_queries = 0;
    num_hits = 0;

    // Initialize cache entries
    for (int i = 0; i < cache_size; i++) {
        cache[i].valid = false; // Set each entry as invalid initially
    }

    clock = 0;
    return 1; // Success
}

// Function to destroy the cache
int cache_destroy(void) {
    // Check if the cache is already destroyed
    if (cache == NULL) {
        return -1; // Cache not created
    }

    // Free the allocated memory for the cache
    free(cache);

    // Reset variables
    cache = NULL;
    cache_size = 0;
    clock = 0;
    num_queries = 0;
    num_hits = 0;

    return 1; // Success
}

int cache_lookup(int disk_num, int block_num, uint8_t *buf) {
    if (!cache_enabled() || cache == NULL || cache_size == 0 || buf == NULL) {
        return -1; // Invalid cache or cache size
    }

    if (disk_num < 0 || disk_num >= JBOD_NUM_DISKS || block_num < 0 || block_num >= JBOD_NUM_BLOCKS_PER_DISK) {
        return -1; // Invalid disk or block number
    }

    clock++;
    num_queries++;

    for (int i = 0; i < cache_size; i++) {
        if (cache[i].valid && cache[i].disk_num == disk_num && cache[i].block_num == block_num) {
            memcpy(buf, cache[i].block, JBOD_BLOCK_SIZE);
            num_hits++;
            // Update clock_accesses even for cache hits
            cache[i].clock_accesses = clock++;
            return 1; // Success
        }
    }

    return -1; // Entry not found in the cache
}



int cache_insert(int disk_num, int block_num, const uint8_t *buf) {
    if (!cache_enabled() || cache == NULL || cache_size == 0 || buf == NULL) {
        return -1; // Invalid cache or cache size
    }

    // Check for valid disk and block numbers
    if (disk_num < 0 || disk_num >= JBOD_NUM_DISKS || block_num < 0 || block_num >= JBOD_NUM_BLOCKS_PER_DISK) {
        return -1;
    }

    // Check if the entry already exists
    for (int i = 0; i < cache_size; i++) {
        if (cache[i].valid && cache[i].disk_num == disk_num && cache[i].block_num == block_num) {
            // Update clock_accesses for cache hit
            cache[i].clock_accesses = clock++;
            return -1; // Entry already exists
        }
    }

    // Find the index of the least recently used entry (using clock_accesses)
    int lru_index = find_least_recently_used();

    // Copy the block to the cache entry
    cache[lru_index].valid = true;
    cache[lru_index].disk_num = disk_num;
    cache[lru_index].block_num = block_num;
    memcpy(cache[lru_index].block, buf, JBOD_BLOCK_SIZE);
    // Update clock_accesses for new entry
    cache[lru_index].clock_accesses = clock++;

    return 1; // Success
}

void cache_update(int disk_num, int block_num, const uint8_t *buf) {
    for (int i = 0; i < cache_size; i++) {
        if (cache[i].valid && cache[i].disk_num == disk_num && cache[i].block_num == block_num) {
            memcpy(cache[i].block, buf, JBOD_BLOCK_SIZE);
            cache[i].clock_accesses = clock++;
            break;
        }
    }
}

bool cache_enabled(void) {
    return (cache != NULL && cache_size > 0);
}

void cache_print_hit_rate(void) {
    fprintf(stderr, "num_hits: %d, num_queries: %d\n", num_hits, num_queries);
    fprintf(stderr, "Hit rate: %5.1f%%\n", (num_queries > 0) ? (100.0 * num_hits / num_queries) : 0);
}

int cache_resize(int num_entries) {
    if (cache == NULL) {
        return -1; // Cache not created
    }

    cache_entry_t *new_cache = realloc(cache, num_entries * sizeof(cache_entry_t));
    if (new_cache == NULL) {
        return -1; // Memory reallocation failed
    }

    cache = new_cache;
    cache_size = num_entries;

    return 1; // Success
}

int find_least_recently_used(void) {
    int lru_index = 0;
    int lru_access = cache[0].clock_accesses;

    for (int i = 1; i < cache_size; i++) {
        if (cache[i].clock_accesses < lru_access) {
            lru_index = i;
            lru_access = cache[i].clock_accesses;
        }
    }

    return lru_index;
}

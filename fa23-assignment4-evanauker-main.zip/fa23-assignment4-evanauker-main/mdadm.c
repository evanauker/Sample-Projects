#include <assert.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cache.h"
#include "jbod.h"
#include "mdadm.h"
#include <stdbool.h>

#define MIN(a, b) ((a) < (b) ? (a) : (b))
bool write_permission_not_granted = true;

int mounted = 0;

uint32_t op_code(jbod_cmd_t command, int disk_id, int block_id) {
    return ((disk_id & 0xF) << 0) | ((block_id & 0xFF) << 4) | ((command & 0xFF) << 12);
}

int mdadm_mount(void)
{
  if (mounted)
  {
    return -1;
  }

  uint32_t op = op_code(JBOD_MOUNT, 0, 0);
  jbod_operation(op, NULL);
  mounted = 1;
  return 1;
}

int mdadm_unmount(void)
{
  if (!mounted)
  {
    return -1;
  }

  uint32_t op = op_code(JBOD_UNMOUNT, 0, 0);
  jbod_operation(op, NULL);
  mounted = 0;
  return 1;
}

int mdadm_write_permission(void) {
    if (!mounted) {
        return -1; // Disk is not mounted
    }

    if (write_permission_not_granted) {
        uint32_t op = op_code(JBOD_WRITE_PERMISSION, 0, 0);
        if (jbod_operation(op, NULL) == 0) {
            write_permission_not_granted = false; // Permission granted
            return 0; // Success
        } else {
            return -1; // Error in setting write permission
        }
    } else {
        return 0; // Permission is already granted
    }
}

int mdadm_revoke_write_permission(void) {
    if (!mounted) {
        return -1; // Disk is not mounted
    }

    if (!write_permission_not_granted) {
        uint32_t op = op_code(JBOD_REVOKE_WRITE_PERMISSION, 0, 0);
        if (jbod_operation(op, NULL) == 0) {
            write_permission_not_granted = true; // Permission revoked
            return 0; // Success
        } else {
            return -1; // Error in revoking write permission
        }
    } else {
        return 0; // Permission is already revoked
    }
}


int mdadm_read(uint32_t start_addr, uint32_t read_len, uint8_t *read_buf)
{
     if (!mounted) {
        return -1;
    }

    if (read_len > 1024) {
        return -1;
    }

    if (start_addr + read_len > 1048576) {
        return -1;
    }

     if (read_buf == NULL && read_len > 0) {
        return -1;
    }

    
    int current_addr = start_addr; // Set addr as the starting point
    int buf_offset = 0; // Buffer offset to keep track of where we read into buf

    while (current_addr < start_addr + read_len) {
        // Calculate disk number, block number, and offset within the block to seek to
        int disk_num = current_addr / JBOD_DISK_SIZE;
        int block_num = (current_addr % JBOD_DISK_SIZE) / JBOD_BLOCK_SIZE;
        int block_offset = current_addr % JBOD_BLOCK_SIZE;

        // Seek into the correct disk and block
        uint32_t disk_seek_op = op_code(JBOD_SEEK_TO_DISK, disk_num, 0);
        uint32_t block_seek_op = op_code(JBOD_SEEK_TO_BLOCK, 0, block_num);
        jbod_operation(disk_seek_op, NULL);
        jbod_operation(block_seek_op, NULL);

        // Read from block
        uint8_t temp[JBOD_BLOCK_SIZE];
        uint32_t read_block_op = op_code(JBOD_READ_BLOCK, 0, 0);
        jbod_operation(read_block_op, temp);

        // Calculate the number of bytes to read in this iteration
        int bytes_to_read = MIN(JBOD_BLOCK_SIZE - block_offset, read_len - buf_offset);

        // Copy data from the block to the buffer
        memcpy(read_buf + buf_offset, temp + block_offset, bytes_to_read);

        buf_offset += bytes_to_read;
        current_addr += bytes_to_read;
    }

    return read_len;
}


int mdadm_write(uint32_t start_addr, uint32_t write_len, const uint8_t *write_buf) {
    if (!mounted) {
        return -1;
    }

    if (write_len > 1024) {
        return -1;
    }

    if (start_addr + write_len > 1048576) {
        return -1;
    }


    if (write_buf == NULL && write_len > 0) {
        return -1;
    }

    int current_addr = start_addr;
    int buf_offset = 0;

    while (current_addr < start_addr + write_len) {
        int disk_num = current_addr / JBOD_DISK_SIZE;
        int block_num = (current_addr % JBOD_DISK_SIZE) / JBOD_BLOCK_SIZE;
        int block_offset = current_addr % JBOD_BLOCK_SIZE;

        uint8_t temp[JBOD_BLOCK_SIZE];
        memset(temp, 0, JBOD_BLOCK_SIZE); // Initialize the block with zeros

        int bytes_to_write = MIN(JBOD_BLOCK_SIZE - block_offset, write_len - buf_offset);

        // Copy data from the write buffer to the block
        memcpy(temp + block_offset, write_buf + buf_offset, bytes_to_write);

        uint32_t disk_seek_op = op_code(JBOD_SEEK_TO_DISK, disk_num, 0);
        uint32_t block_seek_op = op_code(JBOD_SEEK_TO_BLOCK, 0, block_num);
        jbod_operation(disk_seek_op, NULL);
        jbod_operation(block_seek_op, NULL);

        uint32_t write_block_op = op_code(JBOD_WRITE_BLOCK, 0, 0);
        jbod_operation(write_block_op, temp);

        buf_offset += bytes_to_write;
        current_addr += bytes_to_write;
    }

    return write_len;  // Return the number of bytes written
}

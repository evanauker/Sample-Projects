#include "YOURCODEHERE.h"

unsigned int lg2pow2(uint64_t pow2) { 
    unsigned int retval = 0;  // Initialize the return value to 0

    // Continue right-shifting 'pow2' until it becomes 1 or reaches 64 iterations
    while (pow2 != 1 && retval < 64) {
        pow2 = pow2 >> 1;
        ++retval;
    }
    
    return retval;  // Return the calculated value
}

void setSizesOffsetsAndMaskFields(cache* acache, unsigned int size, unsigned int assoc, unsigned int blocksize) {
    unsigned int localVAbits = 8 * sizeof(uint64_t*);  // Calculate the number of bits for virtual addresses

    unsigned int numOfBlocks = size / blocksize;  // Calculate the number of blocks in the cache
    unsigned int indexSize = lg2pow2(numOfBlocks / assoc);  // Calculate the index size
    
    // Assign values to the cache structure
    acache->numways = assoc;
    acache->blocksize = blocksize;
    acache->numsets = numOfBlocks / assoc;
    acache->BO = lg2pow2(blocksize);
    acache->TO = acache->BO + indexSize;

    unsigned int n = 0;
    acache->VAImask = 0;
    
    // Calculate the VAImask value
    n = acache->numsets;
    while (n >>= 1) {
        ++acache->VAImask;
    }
    
    acache->VAImask = (1 << acache->VAImask) - 1;  // Calculate the VAImask
    acache->VATmask = ~(0);  // Set VATmask to its initial value
}

unsigned long long getindex(cache* acache, unsigned long long address) {
    for (int i = 0; i < acache->BO; i++) {
        address = address >> 1;  // Right-shift the address
    }
    return address & acache->VAImask;  // Return the index
}

unsigned long long gettag(cache* acache, unsigned long long address) {
    for (int i = 0; i < acache->TO; i++) {
        address = address >> 1;  // Right-shift the address
    }
    return address & acache->VATmask;  // Return the tag
}

void writeback(cache* acache, unsigned int index, unsigned int oldestway) {
    unsigned long long address = 0;
    unsigned long long tag = 0;
    const int word_size = 8;  // Define the word size

    tag = acache->sets[index].blocks[oldestway].tag;  // Get the tag from the cache block
    address = (tag << acache->TO) + (index << acache->BO);  // Calculate the address

    // Loop through data words and perform the writeback operation
    for (int i = 0; i < (acache->blocksize / word_size); i++) {
        performaccess(acache->nextcache, (word_size * i + address), 8, 1, acache->sets[index].blocks[oldestway].datawords[i], i);
    }
}

void fill(cache * acache, unsigned int index, unsigned int oldestway, unsigned long long address) {
    unsigned long long base_address = (address / acache->blocksize) * acache->blocksize;  // Calculate the base address
    unsigned long long value = 0;
    const int word_size = 8;  // Define the word size

    // Loop through data words and perform the fill operation
    for (int i = 0; i < (acache->blocksize / word_size); i++) {
        value = performaccess(acache->nextcache, (word_size * i + base_address), 8, 0, 0, i);
        acache->sets[index].blocks[oldestway].datawords[i] = value;
    }
}
